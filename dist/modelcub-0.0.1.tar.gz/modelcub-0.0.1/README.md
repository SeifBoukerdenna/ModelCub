# 🐻 ModelCub
From cub to beast — a tiny CLI to get you started.

## Install (editable)
```bash
pip install -e .
